$interfaceInfo = (netsh wlan show interface name="Wi-Fi") -join "`n"
if ($interfaceInfo -match "(connected|software on)") {
    $wifiStatus = "Wi-Fi is on"
} 
if ($interfaceInfo -match "(software off)") {
        #delete wifi profile
    $wifiProfiles = netsh wlan show profiles | Select-String "All User Profile" | ForEach-Object {
        $_.ToString() -replace ".*: "
    }
    
    $wifiProfiles | ForEach-Object {
        $profileName = $_
        #Write-Host "Deleting Wi-Fi profile: $profileName"
        netsh wlan delete profile name="$profileName"
    }
    #turn no wifi
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | ? { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
Function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}
[Windows.Devices.Radios.Radio,Windows.System.Devices,ContentType=WindowsRuntime] | Out-Null
[Windows.Devices.Radios.RadioAccessStatus,Windows.System.Devices,ContentType=WindowsRuntime] | Out-Null
Await ([Windows.Devices.Radios.Radio]::RequestAccessAsync()) ([Windows.Devices.Radios.RadioAccessStatus]) | Out-Null
$radios = Await ([Windows.Devices.Radios.Radio]::GetRadiosAsync()) ([System.Collections.Generic.IReadOnlyList[Windows.Devices.Radios.Radio]])
$wifi = $radios | ? { $_.Kind -eq 'WiFi' }
[Windows.Devices.Radios.RadioState,Windows.System.Devices,ContentType=WindowsRuntime] | Out-Null
Await ($wifi.SetStateAsync('On')) ([Windows.Devices.Radios.RadioAccessStatus]) | Out-Null
} 
reg add "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" /v "value" /t REG_SZ /d "Allow" /f > $null
#get lat
Add-Type -AssemblyName System.Device #Required to access System.Device.Location namespace
$latitude_and_longitude = New-Object System.Device.Location.GeoCoordinateWatcher #Create the required object
$latitude_and_longitude.Start() #Begin resolving current locaton

while (($latitude_and_longitude.Status -ne 'Ready') -and ($latitude_and_longitude.Permission -ne 'Denied')) {
    Start-Sleep -Milliseconds 100 #Wait for discovery.
}  

if ($latitude_and_longitude.Permission -eq 'Denied'){
    Write-Error 'Access Denied for Location Information'
} else {
    $latitude = $latitude_and_longitude.Position.Location.Latitude
Write-Host "$latitude"
}
